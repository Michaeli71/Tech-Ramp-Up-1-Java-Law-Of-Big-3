package a_examples;

import java.util.Iterator;
import java.util.List;

public class EveryNthIterator<E> implements Iterator<E>
{
    private final int step;
    private final List<E> values;
    private int position = 0;
    
    public EveryNthIterator(List<E> values, int step, int offset)
    {
        this.values = values;
        this.step = step;
        this.position = offset;
    }

    @Override
    public boolean hasNext()
    {        
        return position < values.size();
    }

    @Override
    public E next()
    {
        E currentValue = values.get(position);
        
        position += step;
                        
        return currentValue;
    }
}
