package c_solutions.part4;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class CustomerBonus implements Comparable<CustomerBonus> 
{
	private final String name;
	private final LocalDate birthday;
	private String zip;
	private String city;
	
	public CustomerBonus(String name, LocalDate birthday, String zip, String city) {
		this.name = name;
		this.birthday = birthday;
		this.zip = zip;
		this.city = city;
	}
	
	public static void main(String[] args) {
		
		var peter = new CustomerBonus("Peter", LocalDate.of(1987,  10,  14), "52070", "Aachen");
		var michael = new CustomerBonus("Michael", LocalDate.of(1971,  2,  7), "8047", "Z�rich");
		var michael2 = new CustomerBonus("Michael", LocalDate.of(1971,  2,  7), "24106", "Kiel");
		var michael3 = new CustomerBonus("Michael", LocalDate.of(1971,  2,  7), "52070", "Aachen");
		var michael4 = new CustomerBonus("Michael", LocalDate.of(1991,  5,  7), "52070", "Aachen");
		var michael5 = new CustomerBonus("Michael", LocalDate.of(1971,  5,  7), "52070", "Aachen");
		var tim = new CustomerBonus("Tim", LocalDate.of(1971,  3,  27), "24118", "Kiel");

		Set<CustomerBonus> allCustomers = Set.of(peter, michael, michael2, michael3, michael4, michael5, tim);
		
		Set<CustomerBonus> customers = new HashSet<>();
		customers.addAll(allCustomers);
		System.out.println("#hash customers:" + customers.size() + " " + customers);

		Set<CustomerBonus> customers2 = new TreeSet<>();
		customers2.addAll(allCustomers);
		System.out.println("#tree customers:" + customers2.size() + " " + customers2);
	}
	
	@Override
	public String toString() {
		return String.format("Customer [name=%s, birthday=%s, zip=%s, city=%s]", name, birthday, zip, city);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, birthday);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerBonus other = (CustomerBonus) obj;
		return Objects.equals(birthday, other.birthday) && Objects.equals(city, other.city)
				&& Objects.equals(name, other.name) && Objects.equals(zip, other.zip);
	}

	/*
	@Override
	public int compareTo(CustomerBonus other) {		
		int res = name.compareTo(other.name);
		if (res == 0)
		{
			res = zip.compareTo(other.zip);
			if (res == 0)				
			{
				res = city.compareTo(other.city);
				if (res == 0)
				{				
				    res = birthday.compareTo(other.birthday);//					 
				}
			}
		}
		return res;
	}	
	*/
	
	@Override
	public int compareTo(CustomerBonus other) {		
		return byNameZipCityBithday.compare(this, other);
	}	
	
	// BONUS
	
	Comparator<CustomerBonus> byName = (cust1, cust2) -> cust1.getName().compareTo(cust2.getName());
	Comparator<CustomerBonus> byZip = Comparator.comparing(CustomerBonus::getZip);
	Comparator<CustomerBonus> byCity = Comparator.comparing(CustomerBonus::getCity);
	Comparator<CustomerBonus> byBirthday = Comparator.comparing(CustomerBonus::getBirthday);
	Comparator<CustomerBonus> byAllAttributes = byName.thenComparing(byZip).thenComparing(byCity).thenComparing(byBirthday);
	Comparator<CustomerBonus> byNameZipCityBithday = byName.thenComparing(byZip).thenComparing(byCity).thenComparing(byBirthday);

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public LocalDate getBirthday() {
		return birthday;
	}
}
