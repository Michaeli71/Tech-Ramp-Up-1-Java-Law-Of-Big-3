package b_excercises.part4;

import java.util.Collection;

/**
 * Beispielprogramm zur Demonstration einer gr��enbeschr�nkten HashMap mithilfe der 
 * Callback-Methode removeEldestEntry(), die das �lteste Element basierend auf der 
 * Zugriffsreihenfolge bestimmt.
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public final class LruLinkedHashMapExample
{
    public static void main(final String[] args)
    {
        // Gr��enbeschr�nkung auf vier Elemente + JDK 7 Diamond Operator
        final int MAX_ELEMENT_COUNT = 4;
        final LruLinkedHashMap<String, SimpleCustomer> lruMap = new LruLinkedHashMap<>(MAX_ELEMENT_COUNT);

        lruMap.put("Erster", new SimpleCustomer("A. Erster", "Stuhr", 16));
        lruMap.put("Zweiter", new SimpleCustomer("B. Zweiter", "Hamburg", 32));
        lruMap.put("Dritter", new SimpleCustomer("C. Dritter", "Z�rich", 64));
        lruMap.put("M. Inden", new SimpleCustomer("M. Inden", "Kiel", 32));
        printCustomerList("Initial", lruMap.values());

        // Zugriff auf alle bis auf M. Inden           
        lruMap.get("Erster");
        lruMap.get("Zweiter");
        lruMap.get("Dritter");

        // Neuer Eintrag sollte M. Inden ersetzen           
        lruMap.put("Dummy", new SimpleCustomer("D. Dummy", "Oldenburg", 128));
        printCustomerList("Nach Zugriffen", lruMap.values());
        
        // Zugriff auf A. Erster      
        lruMap.get("Erster");
        
        // Neuer Eintrag sollte B. Zweiter ersetzen           
        lruMap.put("LAST", new SimpleCustomer("James LAST", "LONGLASTING", 128));
        printCustomerList("Nach Zugriffen", lruMap.values());
    }

    private static void printCustomerList(final String title, final Collection<SimpleCustomer> customers)
    {
        System.out.println(title);
        for (final SimpleCustomer customer : customers)
            System.out.println(customer);
    }
}
