package c_solutions.part1_2_3;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Person {

	private final String name;
	private final LocalDate birthday;
	private String zip;
	private String city;
	
	public Person(String name, LocalDate birthday, String zip, String city) {
		this.name = name;
		this.birthday = birthday;
		this.zip = zip;
		this.city = city;
	}
	
	public static void main(String[] args) {
		
		Map<Person, List<String>> personToHobbies = new HashMap<>();
		
		var peter = new Person("Peter", LocalDate.of(1987,  10,  14), "52070", "Aachen");
		personToHobbies.put(peter, List.of("Schach", "Tennis", "Kickern"));

		var petersHobbies = personToHobbies.get(peter);
		System.out.println("petersHobbies: " + petersHobbies);
		System.out.println(personToHobbies);
		
		// Peter zieht nach Z�rich
		peter.zip = "8047";
		peter.city = "Z�rich";

		var petersHobbies2 = personToHobbies.get(peter);
		System.out.println("petersHobbies: " + petersHobbies2);
		
		// Peter "nochmal sicherheitshalber einf�gen", neues Hobby Fu�ball
		personToHobbies.put(peter, List.of("Schach", "Tennis", "Kickern", "Fu�ball"));

		var petersHobbies3 = personToHobbies.get(peter);
		System.out.println("petersHobbies: " + petersHobbies3);
		System.out.println(personToHobbies);
	}

	
	

	@Override
	public String toString() {
		return String.format("Person [name=%s, birthday=%s, zip=%s, city=%s]", name, birthday, zip, city);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, birthday);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Person other = (Person) obj;
		return Objects.equals(birthday, other.birthday) && Objects.equals(city, other.city)
				&& Objects.equals(name, other.name) && Objects.equals(zip, other.zip);
	}	
}
