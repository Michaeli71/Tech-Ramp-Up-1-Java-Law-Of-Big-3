package b_excercises.part5;

import java.util.Iterator;
import java.util.List;

/**
 * Beispielprogramm im Rahmen des Workshops der JAVA PROFI ACADEMY
 * 
 * @author Michael Inden
 * 
 * Copyright 2020 by Michael Inden 
 */
public class Every2ndListIterator<E> implements Iterator<E>
{
    private final List<E> original;

    Every2ndListIterator(List<E> original)
    {
        this.original = original;
    }

    @Override
    public boolean hasNext()
    {
        return false;
    }

    @Override
    public E next()
    {        
        return null;
    }

    public static void main(String[] args)
    {
        List<Integer> values = List.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);

        Iterator<Integer> it = new Every2ndListIterator<>(values);
        while (it.hasNext())
        {
            System.out.println(it.next());
        }
        
        System.out.println("------------------");

        List<String> lines = List.of("Line1", "Tim", "Line2", "Tom", "Line3", "Mike");
        Iterator<String> it2 = new Every2ndListIterator<>(lines);
        while (it2.hasNext())
        {
            System.out.println(it2.next());
        }
    }
}
