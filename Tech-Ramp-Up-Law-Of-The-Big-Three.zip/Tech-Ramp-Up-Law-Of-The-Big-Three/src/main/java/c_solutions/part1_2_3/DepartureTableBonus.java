package c_solutions.part1_2_3;

import java.util.List;
import java.util.Objects;

public class DepartureTableBonus {

	List<String> greetings = List.of("Guten Morgen", "Guten Tag", "Guten Abend");

	List<List<String>> lineDestinations = List.of(List.of("1", "Hauptbahnhof"), 
			List.of("2", "S�dfriedhof"),
			List.of("3", "Zentralstrasse"), 
			List.of("4", "Flugharen"), 
			List.of("11", "Hauptbahnhof OST"));

	public static void main(String[] args) {

		var dt1 = new DepartureTableBonus();
		var dt2 = new DepartureTableBonus();

		System.out.println(dt1.equals(dt2));
	}

	@Override
	public int hashCode() {
		return Objects.hash(greetings, lineDestinations);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DepartureTableBonus other = (DepartureTableBonus) obj;
		return Objects.equals(greetings, other.greetings) && Objects.equals(lineDestinations, other.lineDestinations);
	}
}
