package b_excercises.part4;

import java.util.Objects;

/**
 * Beispielklasse zur Demonstration einzelner Map-Funktionalit�ten
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
final class SimpleCustomer
{
    private final String name;
    private final String city;
    private final int    age;
    
    SimpleCustomer(final String name, final String city, final int age)
    {
        this.name = name;
        this.city = city;
        this.age = age;
    }

    @Override
    public String toString()
    {
        return "Customer [name=" + name + ", city=" + city + ", age=" + age + "]";
    }

	@Override
	public int hashCode() {
		return Objects.hash(age, city, name);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SimpleCustomer other = (SimpleCustomer) obj;
		return age == other.age && Objects.equals(city, other.city) && Objects.equals(name, other.name);
	}  
}