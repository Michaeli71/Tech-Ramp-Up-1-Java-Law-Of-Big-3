package b_excercises.part1_2_3;

import java.util.Objects;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class DepartureTable {

	String[] greetings = {"Guten Morgen", "Guten Tag", "Guten Abend"}; 
	
	String[][] lineDestinations = {
			{"1", "Hauptbahnhof"},
			{"2", "S�dfriedhof"},
			{"3", "Zentralstrasse"},
			{"4", "Flugharen"},
			{"11", "Hauptbahnhof OST"},
	};

	@Override
	public int hashCode() {
		return Objects.hash(greetings, lineDestinations);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		final DepartureTable other = (DepartureTable) obj;
		return Objects.equals(greetings, other.greetings) && Objects.equals(lineDestinations, other.lineDestinations);
	}

	public static void main(String[] args) {

		var dt1 = new DepartureTable();
		var dt2 = new DepartureTable();

		System.out.println(dt1.equals(dt2));
	}
}
