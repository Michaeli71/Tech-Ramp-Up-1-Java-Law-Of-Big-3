package b_excercises.part4;

import java.util.LinkedHashMap;

/**
 * Realisierung einer gr��enbeschr�nkten HashMap mithilfe der Callback-Methode removeEldestEntry(),
 * die das �lteste Element basierend auf der Einf�gereihenfolge bestimmt.
 * 
 * @author Michael Inden
 * 
 * Copyright 2011 by Michael Inden 
 */
public final class FixedSizeLinkedHashMap<K, V> extends LinkedHashMap<K, V>
{
    public FixedSizeLinkedHashMap(final int maxEntryCount)
    {
    }
}
