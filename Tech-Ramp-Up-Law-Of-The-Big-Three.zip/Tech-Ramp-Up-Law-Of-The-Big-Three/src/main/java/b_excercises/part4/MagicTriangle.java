package b_excercises.part4;

import java.util.List;

/**
 * Beispielprogramm für den HAPAG-LLOYD-Workshop und das Buch "Einfach Java"
 *
 * @author Michael Inden
 *
 * Copyright 2021 by Michael Inden
 */
public class MagicTriangle
{
    private MagicTriangle()
    {
    }

    // IDX: 0 1   2   3   4   5 (0/6)
    // VAL: 1 5 [ 3 ] 4 [ 2 ] 6 (1)
    //      _________
    //            _________
    //                    _________
    static boolean isMagic6(final List<Integer> values)
    {
        return false;
    }
    
    public static void main(String[] args)
    {
        var values = List.of(1, 5, 3, 4, 2, 6);
        System.out.println(isMagic6(values));

        var values2 = List.of(1, 5, 6, 4, 2, 3);
        System.out.println(isMagic6(values2));
    }
}
