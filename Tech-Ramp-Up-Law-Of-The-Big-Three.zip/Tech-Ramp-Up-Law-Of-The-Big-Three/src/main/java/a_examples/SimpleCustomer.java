package a_examples;

/**
 * Beispielklasse zur Demonstration einzelner Map-Funktionalit�ten
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
final class SimpleCustomer
{
    private String name;
    private String city;
    private int    age;
    
    SimpleCustomer(final String name, final String city, final int age)
    {
        this.name = name;
        this.city = city;
        this.age = age;
    }

    @Override
    public String toString()
    {
        return "Customer [name=" + name + ", city=" + city + ", age=" + age + "]";
    }
}