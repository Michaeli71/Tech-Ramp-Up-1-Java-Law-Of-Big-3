package c_solutions.part4;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Customer implements Comparable<Customer> 
{
	private final String name;
	private final LocalDate birthday;
	private String zip;
	private String city;
	
	public Customer(String name, LocalDate birthday, String zip, String city) {
		this.name = name;
		this.birthday = birthday;
		this.zip = zip;
		this.city = city;
	}
	
	public static void main(String[] args) {
		
		var peter = new Customer("Peter", LocalDate.of(1987,  10,  14), "52070", "Aachen");
		var michael = new Customer("Michael", LocalDate.of(1971,  2,  7), "8047", "Z�rich");
		var michael2 = new Customer("Michael", LocalDate.of(1971,  2,  7), "24106", "Kiel");
		var michael3 = new Customer("Michael", LocalDate.of(1971,  2,  7), "52070", "Aachen");
		var michael4 = new Customer("Michael", LocalDate.of(1991,  5,  7), "52070", "Aachen");
		var michael5 = new Customer("Michael", LocalDate.of(1971,  5,  7), "52070", "Aachen");
		var tim = new Customer("Tim", LocalDate.of(1971,  3,  27), "24118", "Kiel");

		Set<Customer> allCustomers = Set.of(peter, michael, michael2, michael3, michael4, michael5, tim);
		
		Set<Customer> customers = new HashSet<>();
		customers.addAll(allCustomers);
		System.out.println("#hash customers:" + customers.size() + " " + customers);

		Set<Customer> customers2 = new TreeSet<>();
		customers2.addAll(allCustomers);
		System.out.println("#tree customers:" + customers2.size() + " " + customers2);
	}
	
	@Override
	public String toString() {
		return String.format("Customer [name=%s, birthday=%s, zip=%s, city=%s]", name, birthday, zip, city);
	}

	@Override
	public int hashCode() {
		return Objects.hash(name, birthday);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		return Objects.equals(birthday, other.birthday) && Objects.equals(city, other.city)
				&& Objects.equals(name, other.name) && Objects.equals(zip, other.zip);
	}

	@Override
	public int compareTo(Customer other) {		
		int res = name.compareTo(other.name);
		if (res == 0)
		{
			res = zip.compareTo(other.zip);
			if (res == 0)				
			{
				res = city.compareTo(other.city);
				if (res == 0)
				{				
				    res = birthday.compareTo(other.birthday);//					 
				}
			}
		}
		return res;
	}		
}
