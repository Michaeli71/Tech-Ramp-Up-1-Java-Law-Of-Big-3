package c_solutions.part1_2_3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class Order {

	private int orderld;
	private String orderName;

	public Order(int orderld, String orderName) {
		this.orderld = orderld;
		this.orderName = orderName;
	}

	public int getOrderld() {
		return orderld;
	}

	public void setOrderld(int orderld) {
		this.orderld = orderld;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	@Override
	public String toString() {
		return String.format("Order [orderld=%s, ordername=%s]", orderld, orderName);
	}

	@Override
	public int hashCode() {
		return Objects.hash(orderld, orderName);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		Order other = (Order) obj;
		return orderld == other.orderld && Objects.equals(orderName, other.orderName);
	}

	public static void main(String[] args) {
		Order order1 = new Order(1000, "ABC");
		Order order2 = new Order(1000, "ABC");
		Order order3 = new Order(2000, "MBP");
		Order order4 = new Order(2000, "MBP");
		System.out.println(order1 == order2);
		System.out.println(order1.equals(order2));

		var orders = new ArrayList<>();
		orders.add(order1);
		orders.add(order2);
		orders.add(order3);
		orders.add(order4);
		System.out.println(orders);

		var orderSet = new HashSet<>();
		orderSet.addAll(List.of(order1, order2, order3, order4));
		System.out.println(orderSet);
	}
}