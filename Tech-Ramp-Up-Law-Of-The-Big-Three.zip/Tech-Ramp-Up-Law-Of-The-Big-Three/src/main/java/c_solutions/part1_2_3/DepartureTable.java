package c_solutions.part1_2_3;

import java.util.Arrays;

/**
 * Beispielprogramm f�r Law Of The Big Three Workshop 
 * 
 * @author Michael Inden
 * 
 * Copyright 2022 by Michael Inden 
 */
public class DepartureTable {

	String[] greetings = {"Guten Morgen", "Guten Tag", "Guten Abend"}; 
	
	String[][] lineDestinations = {
			{"1", "Hauptbahnhof"},
			{"2", "S�dfriedhof"},
			{"3", "Zentralstrasse"},
			{"4", "Flugharen"},
			{"11", "Hauptbahnhof OST"},
	};
	
	public static void main(String[] args) {
		 
		var dt1 = new DepartureTable();
		var dt2 = new DepartureTable();		
		
		System.out.println(dt1.equals(dt2));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(greetings);
		result = prime * result + Arrays.deepHashCode(lineDestinations);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DepartureTable other = (DepartureTable) obj;
		return Arrays.equals(greetings, other.greetings) && Arrays.deepEquals(lineDestinations, other.lineDestinations);
	}
}
